<?php

ini_set('display_startup_errors',1);
ini_set('display_errors',1);
error_reporting(-1);
ini_set('display_errors','On'); 

$target_dir = "/var/www/html/uploads/";
$name = $_FILES["fileToUpload"]["name"];
$md5_name = md5($name);
$temp = $_FILES["fileToUpload"]["tmp_name"];


if(isset($_POST["submit"])) {

	if ($name != "") {

		move_uploaded_file($temp , $target_dir . $md5_name);
		$command = "/bin/run_sandbox " . $target_dir . $md5_name . " 2>&1";

		
		$output = shell_exec($command);
		echo "<pre>$output</pre>";

		shell_exec("rm " . $target_dir . $md5_name);
	} else {

		echo "You tryna be funny with names mate? >:(";

	}

}

?>
