<!DOCTYPE html>
<html>
<body>

<form action="upload.php" method="post" enctype="multipart/form-data">
  Select file to upload:
  <input type="file" name="fileToUpload" id="fileToUpload">
  <input type="submit" value="Upload File" name="submit">
</form>

</body>
</html>


<style>

body  {
  background-image: url("images/sandbox.jpg");
  background-size: cover;
  background-repeat: no-repeat;
  background-position: center center;
}


</style>
