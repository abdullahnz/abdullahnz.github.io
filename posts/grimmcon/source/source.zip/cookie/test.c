#include<stdio.h>

int main()
{   
    char x[0x10] = "ABCDEFGH";
    x[5] = 0x00;

    puts(x);
}
